#!/bin/bash
./convert -depth 8 logo.png bgr:logo.raw
./rgb2565 -rle <logo.raw> initlogo.rle
