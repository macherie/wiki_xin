ADFHOST69="http://csdnim.allyes.com";
ADFCID69=15;
ADFBID69=69;
ADFLOC='CNSH0000';
ADFUSER69="http://csdnim.allyes.com/c?d=csdnim&i=z15,10143391,69,151&rf=http%3A%2F%2Fblog.csdn.net%2Fcommon%2Fad.html%3Ft%3D4%26containerId%3Dad_cen%26frmId%3Dad_frm_0&a=dPAVajlhJ2A5yG87AN4Vcwktl&u=";
ALLYESID4="9DeM60A70NbDAnlL";
ADFPGC="2,5,15,0,72,69,151,10143391";

document.write("<script async src=\"//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js\"></Scr"+"ipt>\n");
document.write("<!-- ����Ƶ������ҳ�·�Banner -->\n");
document.write("<ins class=\"adsbygoogle\"\n");
document.write("     style=\"display:inline-block;width:728px;height:90px\"\n");
document.write("     data-ad-client=\"ca-pub-1076724771190722\"\n");
document.write("     data-ad-slot=\"8434233040\"></ins>\n");
document.write("<script>\n");
document.write("(adsbygoogle = window.adsbygoogle || []).push({});\n");
document.write("</Scr"+"ipt>");

