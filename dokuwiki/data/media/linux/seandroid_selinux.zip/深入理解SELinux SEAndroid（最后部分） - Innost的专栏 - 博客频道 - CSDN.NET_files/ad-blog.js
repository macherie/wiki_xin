﻿var ad_type = 'ms1134';
var ad_sc = '<script type="text/javascript" '
    + 'src="http://ad.csdn.net/scripts/ad-' + ad_type + '.js"'
    + '></'
    + 'script>';
document.writeln(ad_sc);

 ad_type = 'ms1126_2';
 ad_sc = '<script type="text/javascript" '
    + 'src="http://ad.csdn.net/scripts/ad-' + ad_type + '.js"'
    + '></'
    + 'script>';
document.writeln(ad_sc);

 ad_type = 'js1129_3';
 ad_sc = '<script type="text/javascript" '
    + 'src="http://ad.csdn.net/scripts/ad-' + ad_type + '.js"'
    + '></'
    + 'script>';
document.writeln(ad_sc);
/*
 ad_type = 'js1107_4';
 ad_sc = '<script type="text/javascript" '
    + 'src="http://ad.csdn.net/scripts/ad-' + ad_type + '.js"'
    + '></'
    + 'script>';
document.writeln(ad_sc);

 ad_type = 'ms846_5';
 ad_sc = '<script type="text/javascript" '
    + 'src="http://ad.csdn.net/scripts/ad-' + ad_type + '.js"'
    + '></'
    + 'script>';
document.writeln(ad_sc);
*/